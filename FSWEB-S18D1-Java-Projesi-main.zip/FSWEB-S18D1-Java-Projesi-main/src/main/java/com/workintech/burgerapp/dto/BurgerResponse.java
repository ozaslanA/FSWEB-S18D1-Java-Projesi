package com.workintech.burgerapp.dto;

public record BurgerResponse(String name, double price) {
}
