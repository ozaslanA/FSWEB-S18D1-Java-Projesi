package com.workintech.burgerapp.entity;

public enum BreadType {
    BURGER,
    WRAP,
    DOUBLE
}
